TOBU LESSON AUDIO ZIP MATCHING GUIDE
====================================

How to name your audio files in the ZIP:

1. MATCH BY AUDIO FILENAME (RECOMMENDED):
   - Set the 'Audio Filename' column in your Excel sheet (e.g. 'n5_l01_v01.mp3').
   - Name your MP3 file in the ZIP archive: 'n5_l01_v01.mp3'.
   - Works for both Vocab and Quiz questions!

2. FALLBACK MATCHING (BY PROMPT / WORD):
   - If 'Audio Filename' in Excel is empty, the system can match by Japanese Word (e.g., 'こんにちは.mp3')
     or Quiz Question ID / prompt text.

Supported Audio Formats: .mp3, .wav, .m4a, .ogg, .aac, .webm
